

__ALL__ = ['correlate','keyDetect','metrical']
